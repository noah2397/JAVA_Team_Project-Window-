import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollPane;

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.awt.Dimension;

public class Window extends JFrame implements ActionListener{
	private static JLabel noah_clock1=new JLabel();
	private static JLabel noah_clock2=new JLabel();
	private JLabel imageLabel = new JLabel();
	private ImageIcon noah_background;
	private String noah_searching_input;
	private JTextField  comp;
	public Window()
	{
		super();
		setSize(1100,600);
		setTitle("Window");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		
		
		JPanel noah_bottom = new JPanel();
		noah_bottom.setLayout(new GridLayout(1,11));
		JPanel noah_clockPanel=new JPanel();
		noah_clockPanel.setLayout(new GridLayout(2,1));
		JPanel application=new JPanel();
		application.setLayout(new FlowLayout());
		

		ImageIcon noah_txt=new ImageIcon(this.getClass().getResource("txt.png"));
		ImageIcon noah_image=new ImageIcon(this.getClass().getResource("search.gif"));
		ImageIcon noah_window=new ImageIcon(this.getClass().getResource("window.gif"));
		JButton noah_search = new JButton("search",noah_image);
		JButton noah_windowb = new JButton("",noah_window);
		JButton noah_txtb = new JButton("text",noah_txt);
		noah_search.setBackground(Color.white);
		noah_windowb.setBackground(Color.white);
		noah_txtb.setBackground(Color.white);
		noah_search.setBorderPainted(false);
		noah_windowb.setBorderPainted(false);
		noah_txtb.setBorderPainted(false);
		noah_txtb.addActionListener(this);
		noah_search.addActionListener(this);
		noah_clockPanel.setBackground(Color.white);
		noah_clockPanel.add(noah_clock1);
		noah_clockPanel.add(noah_clock2);
		noah_bottom.add(noah_windowb);
		noah_bottom.add(noah_search); //�� �ؿ� �ֱ�
		noah_bottom.add(noah_clockPanel);
		add(noah_txtb, BorderLayout.NORTH);
		
		noah_background = new ImageIcon(this.getClass().getResource("ffikka.png")); //���ȭ�� �Ҵ�
        imageLabel.setIcon(noah_background);
        
        
        add(noah_bottom, BorderLayout.SOUTH);//�ؿ� �ֱ�
      

		
		
		
		
		
		
	}
	public static void main(String[] args) {
		Window test=new Window();
		test.setVisible(true);
		timeget();
	}

	
	public void actionPerformed(ActionEvent e) {
		String command=e.getActionCommand();
		if(command.equals("text"))
		{
			txtopen();
			setLocation(0,0);
		}
		if(command.contentEquals("search"))
		{
			searchopen();
		}
		if(command.contentEquals("�Է�"))
		{
			noah_searching_input=comp.getText();
			if(noah_searching_input.contentEquals("search"))
			{
				setLocation(0,0);
				searchopen();
			}
			
		}
				
	}
	
	public void paint(Graphics g)
	{
		super.paint(g);
		
		g.drawImage(noah_background.getImage(), 0, 0, null);
		
		
	}
	public static void txtopen()
	{
		int x,y;
		JFrame txt = new JFrame();
		txt.setTitle("txt");
		txt.setSize(200,200);
		txt.setVisible(true);
		txt.setLocation(400,400);
		txt.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}
	public void searchopen()
	{
		int x,y;
		JFrame txt = new JFrame();
		txt.setLayout(new GridLayout(2,1));
		txt.setTitle("txt");
		txt.setSize(200,200);
		txt.setVisible(true);
		txt.setLocation(400,400);
		txt.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		comp=new JTextField(20);
		JButton input = new JButton("�Է�");
		input.addActionListener(this);
		txt.add(comp);
		txt.add(input);
	}
	public static void timeget()
	{while(true)
	{
		Calendar t=Calendar.getInstance();
		int year = t.get(Calendar.YEAR);
		int month = t.get(Calendar.MONTH)+1;
		int date = t.get(Calendar.DATE)+1;
		int amPm = t.get(Calendar.AM_PM);
		int hour =t.get(Calendar.HOUR);
		int min =t.get(Calendar.MINUTE);
		int sec =t.get(Calendar.SECOND);
		int day=t.get(Calendar.DAY_OF_WEEK)+1;
		String ampm=amPm==Calendar.AM? "PM":"AM";
		noah_clock1.setText(year + "." + month +"." + day);
		noah_clock2.setText(ampm + hour+"."+min+"."+sec);
		try {
			Thread.sleep(1000);
		}catch(Exception e) {}
		
		}
	}}
