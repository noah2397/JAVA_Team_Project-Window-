import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class WorldClockDemo extends JFrame implements ActionListener
{
 

    private JTextField time;
    private JLabel label1;
    private static JLabel label1_time = new JLabel();
    private JLabel label2;
    private static JLabel label2_time = new JLabel();
    private JLabel label3;
    private static JLabel label3_time = new JLabel();
    private JLabel label4;
    private static JLabel label4_time = new JLabel();
    private JLabel label5;
    private static JLabel label5_time = new JLabel();
    private JLabel label6;
    private static JLabel label6_time = new JLabel();

    public static void main(String[] args)
    {
    	WorldClockDemo gui = new WorldClockDemo();
        gui.setVisible(true);
        timeget2();
    }

    public WorldClockDemo()
    {
        super( );
        setSize(500,500);
        setTitle("World Clock Demonstration");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new BorderLayout());
        
        JPanel timePanel = new JPanel();
        timePanel.setLayout(new FlowLayout());
        timePanel.setBackground(Color.WHITE);
        JLabel show = new JLabel("Calculate your time: ");
        timePanel.add(show);
        time = new JTextField("This text will show the current time all around the world.");
        time.setEditable(false);
        timePanel.add(time);
        add(timePanel, BorderLayout.NORTH);
        
        JPanel worldPanel = new JPanel();
        worldPanel.setLayout(new GridLayout(4, 3));

        label1 = new JLabel("Korea/Seoul");
        worldPanel.add(label1);
        label2 = new JLabel("China/Shanghai");
        worldPanel.add(label2);
        label3 = new JLabel("USA/New York");
        worldPanel.add(label3);
        worldPanel.add(label1_time);
        worldPanel.add(label2_time);
        worldPanel.add(label3_time);
        label4 = new JLabel("Europe/Paris");
        worldPanel.add(label4);
        label5 = new JLabel("Japan/Tokyo");
        worldPanel.add(label5);
        label6 = new JLabel("Vietnam/Hanoi");
        worldPanel.add(label6);
        worldPanel.add(label4_time);
        worldPanel.add(label5_time);
        worldPanel.add(label6_time);
        
        add(worldPanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2, 3));
        
        JButton button1 = new JButton("Korea/Seoul");
        button1.addActionListener(this);
        buttonPanel.add(button1);
        JButton button2 = new JButton("China/Shanghai");
        button2.addActionListener(this);
        buttonPanel.add(button2);
        JButton button3 = new JButton("USA/New York");
        button3.addActionListener(this);
        buttonPanel.add(button3);
        JButton button4 = new JButton("Europe/Paris");
        button4.addActionListener(this);
        buttonPanel.add(button4);
        JButton button5 = new JButton("Japan/Tokyo");
        button5.addActionListener(this);
        buttonPanel.add(button5);
        JButton button6 = new JButton("Vietnam/Hanoi");
        button6.addActionListener(this);
        buttonPanel.add(button6);
        
        add(buttonPanel, BorderLayout.SOUTH);
        
    }
    
    public static void timeget2()
    {
    	
    	while(true) {
    		Calendar t=Calendar.getInstance();
    		int year9 = t.get(Calendar.YEAR);
    		int month9 = t.get(Calendar.MONTH)+1;
    		int date9 = t.get(Calendar.DATE)+1;
    		int amPm9 = t.get(Calendar.AM_PM);
    		int hour9 =t.get(Calendar.HOUR);
    		int min9 =t.get(Calendar.MINUTE);
    		int sec9 =t.get(Calendar.SECOND);
    		int day9=t.get(Calendar.DAY_OF_WEEK)+1;
    		String ampm9=amPm9==Calendar.AM? "PM":"AM";
			Window.noah_clock1.setText(year9 + "." + month9 +"." + day9);
    		Window.noah_clock2.setText(ampm9 + hour9+"."+min9+"."+sec9);
    		
    		
    		
    		Calendar t1=Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul"));
    		int year = t1.get(Calendar.YEAR);
    		int month = t1.get(Calendar.MONTH)+1;
    		int date = t1.get(Calendar.DATE)+1;
    		int amPm = t1.get(Calendar.AM_PM);
    		int hour=t1.get(Calendar.HOUR);
    		int min=t1.get(Calendar.MINUTE);
    		int sec=t1.get(Calendar.SECOND);
    		int day=t1.get(Calendar.DAY_OF_WEEK)+1;
    		String ampm=amPm==Calendar.AM? "AM":"PM";
    		label1_time.setText(ampm + hour+":"+min+":"+sec);
    		
    		Calendar t2=Calendar.getInstance(TimeZone.getTimeZone("Asia/Shanghai"));
    		int year2 = t2.get(Calendar.YEAR);
    		int month2 = t2.get(Calendar.MONTH)+1;
    		int date2 = t2.get(Calendar.DATE)+1;
    		int amPm2 = t2.get(Calendar.AM_PM);
    		int hour2=t2.get(Calendar.HOUR);
    		int min2=t2.get(Calendar.MINUTE);
    		int sec2=t2.get(Calendar.SECOND);
    		int day2=t2.get(Calendar.DAY_OF_WEEK)+1;
    		String ampm2=amPm2==Calendar.AM? "AM":"PM";
    		label2_time.setText(ampm2 + hour2+":"+min2+":"+sec2);
    		
    		Calendar t3=Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
    		int year3 = t3.get(Calendar.YEAR);
    		int month3 = t3.get(Calendar.MONTH)+1;
    		int date3 = t3.get(Calendar.DATE)+1;
    		int amPm3 = t3.get(Calendar.AM_PM);
    		int hour3=t3.get(Calendar.HOUR);
    		int min3=t3.get(Calendar.MINUTE);
    		int sec3=t3.get(Calendar.SECOND);
    		int day3=t3.get(Calendar.DAY_OF_WEEK)+1;
    		String ampm3=amPm3==Calendar.AM? "AM":"PM";
    		label3_time.setText(ampm3 + hour3+":"+min3+":"+sec3);
    		
    		Calendar t4=Calendar.getInstance(TimeZone.getTimeZone("Europe/Paris"));
    		int year4 = t4.get(Calendar.YEAR);
    		int month4 = t4.get(Calendar.MONTH)+1;
    		int date4 = t4.get(Calendar.DATE)+1;
    		int amPm4 = t4.get(Calendar.AM_PM);
    		int hour4=t4.get(Calendar.HOUR);
    		int min4=t4.get(Calendar.MINUTE);
    		int sec4=t4.get(Calendar.SECOND);
    		int day4=t4.get(Calendar.DAY_OF_WEEK)+1;
    		String ampm4=amPm4==Calendar.AM? "AM":"PM";
    		label4_time.setText(ampm4 + hour4+":"+min4+":"+sec4);
    		
    		Calendar t5=Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"));
    		int year5 = t5.get(Calendar.YEAR);
    		int month5 = t5.get(Calendar.MONTH)+1;
    		int date5 = t5.get(Calendar.DATE)+1;
    		int amPm5 = t5.get(Calendar.AM_PM);
    		int hour5=t5.get(Calendar.HOUR);
    		int min5=t5.get(Calendar.MINUTE);
    		int sec5=t5.get(Calendar.SECOND);
    		int day5=t5.get(Calendar.DAY_OF_WEEK)+1;
    		String ampm5=amPm5==Calendar.AM? "AM":"PM";
    		label5_time.setText(ampm5 + hour5+":"+min5+":"+sec5);
    		
    		Calendar t6=Calendar.getInstance(TimeZone.getTimeZone("Asia/Hanoi"));
    		int year6 = t6.get(Calendar.YEAR);
    		int month6 = t6.get(Calendar.MONTH)+1;
    		int date6 = t6.get(Calendar.DATE)+1;
    		int amPm6 = t6.get(Calendar.AM_PM);
    		int hour6=t6.get(Calendar.HOUR);
    		
    		int min6=t6.get(Calendar.MINUTE);
    		int sec6=t6.get(Calendar.SECOND);
    		int day6=t6.get(Calendar.DAY_OF_WEEK)+1;
    		String ampm6=amPm6==Calendar.AM? "AM":"PM";
    		label6_time.setText(ampm6 + hour6+":"+min6+":"+sec6);
    		try {
    			Thread.sleep(1000);
    		} catch(Exception e) {
    			System.out.println("Error");
    		}
        }
    }
    
    public void actionPerformed(ActionEvent e) {
    	 String actionCommand = e.getActionCommand();
    	 Calendar t1=Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul"));
    	 int hour=t1.get(Calendar.HOUR);
 		 int min=t1.get(Calendar.MINUTE);
 		 int sec=t1.get(Calendar.SECOND);
 		 Calendar t2=Calendar.getInstance(TimeZone.getTimeZone("Asia/Shanghai"));
    	 int hour2=t2.get(Calendar.HOUR);
 		 int min2=t2.get(Calendar.MINUTE);
 		 int sec2=t2.get(Calendar.SECOND);
 		 Calendar t3=Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
 		 int hour3=t3.get(Calendar.HOUR);
		 int min3=t3.get(Calendar.MINUTE);
		 int sec3=t3.get(Calendar.SECOND);
 		 Calendar t4=Calendar.getInstance(TimeZone.getTimeZone("Europe/Paris"));
 		 int hour4=t4.get(Calendar.HOUR);
		 int min4=t4.get(Calendar.MINUTE);
		 int sec4=t4.get(Calendar.SECOND);
 		 Calendar t5=Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"));
 		 int hour5=t5.get(Calendar.HOUR);
		 int min5=t5.get(Calendar.MINUTE);
		 int sec5=t5.get(Calendar.SECOND);
 		 Calendar t6=Calendar.getInstance(TimeZone.getTimeZone("Asia/Hanoi"));
 		 int hour6=t6.get(Calendar.HOUR);
		 int min6=t6.get(Calendar.MINUTE);
		 int sec6=t6.get(Calendar.SECOND);
    	 
    	 if (actionCommand.equals("Korea/Seoul"))
    	 {
    		 time.setText("You're already living in Korea.");
    	 }
    	 else if (actionCommand.equals("China/Shanghai"))
    	 {
    		 time.setText("It takes time to Shanghai for "
    	 +Integer.toString(Math.abs(hour2-hour))+" hours.");
    	 }
    	 else if (actionCommand.equals("USA/New York"))
    	 {
    		 time.setText("It takes time to New York for "
    	 +Integer.toString(Math.abs(hour3+12-hour))+" hours.");
    	 }
    	 else if (actionCommand.equals("Europe/Paris"))
    	 {
    		 time.setText("It takes time to Paris for "
    	 +Integer.toString(Math.abs(hour4-hour))+" hours.");
    	 }
    	 else if (actionCommand.equals("Vietnam/Hanoi"))
    	 {
    		 time.setText("It takes time to Hanoi for "
    	 +Integer.toString(Math.abs(hour6-hour))+" hours.");
    	 }
    	 else if (actionCommand.equals("Japan/Tokyo"))
    	 {
    		 time.setText("Fortunately, Japan uses the same time zone as Korea.");
    	 }
    	 else
             System.out.println("Unexpected Error.");
    }
}

